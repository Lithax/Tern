Lithax Tern by @Lithax

Hello! Welcome and thank you for downloading tern.

Tern is a encryption compression and more CLI tool

In order to properly use tern, its advised to run 'env.bat' under the bin/ folder,
which will add tern to the Systemenviroment variables

This Packet does not include a JRE, instead it relies on the already installed local JDK/JRE (MUST BE ABOVE JAVA 17) which for this distribution, is mandatory, if you dont jave a JRE,
then download the other tern distribution (comes with a minimal JRE) to use without a local one.

Thanks for reading!